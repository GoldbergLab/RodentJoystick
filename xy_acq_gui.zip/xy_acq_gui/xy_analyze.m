 function xy_analyze(src,event)
 global buff;
 global buff_count;
 global write_count;
 global frame_countdown;
     
     data = event.Data;
     buff = [buff(:,1001:end) data'];
     buff_count = buff_count+1;
     diff = abs(data' - [2.7;2.7;0.18;0.01;2.7;2.7;0.18;0.01;2.7;2.7;0.18;0.01;2.7;2.7;0.18;0.01]*ones(size(data,1),1)');
     diff_sum = sum(diff,2);
     
     if (diff_sum(3)>140 || diff_sum(4)>120)
         frame_countdown=30;
     end
      
     if frame_countdown>0
        frame_countdown = frame_countdown-1;
     end
     
     if ((buff_count>10)&&frame_countdown>0)
         buff_count=0;
         write_count = write_count+1;
         save(strcat('trig_rec_data_mouse1-3',num2str(write_count)),'buff');
     elseif buff_count>10
         buff_count=0;
     end
 end